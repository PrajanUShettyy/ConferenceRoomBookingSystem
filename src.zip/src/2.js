import React from "react";
import './2.css';

export const Box=()=>
{
    return (
        <div>Box</div>
    )
}