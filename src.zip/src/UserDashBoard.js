import React, { useEffect, useState } from "react";
import "./UserDashBoard.css";

const UserDashBoard = () => 
{
  const [bookings, setBookings] = useState([]);

  console.log(bookings);
  
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/bookings");
        const data = await response.json();
        setBookings(data);
      } 
      catch (error) 
      {
        console.error("Error fetching bookings:", error);
      }
    };

    fetchBookings();
  }, []);

  const formatDate = (dateTime) => {
    const date = new Date(dateTime);
    return date.toLocaleDateString();
  };

  const formatTime = (dateTime) => {
    const date = new Date(dateTime);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="admin-dashboard">
      <h2>User Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>User Name</th>
            <th>Company</th>
            <th>Conference Room</th>
            <th>Date</th>
            <th>Start Time</th>
            <th>End Time</th>
          </tr>
        </thead>
        <tbody>

          {bookings.map((booking) => (
            <tr key={booking.book_id}>
              <td>{booking.userDetails.userName}</td>
              <td>{booking.userDetails.company.company_name}</td>
              <td>{booking.confRoom.confName}</td>
              <td>{formatDate(booking.startTime)}</td>
              <td>{formatTime(booking.startTime)}</td>
              <td>{formatTime(booking.endTime)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserDashBoard;









// import React, { useEffect, useState } from "react";
// import "./UserDashBoard.css";

// const UserDashBoard = () => {
//     const [bookings, setBookings] = useState([]);
//     const [filteredBookings, setFilteredBookings] = useState([]);

//     // Fetch user details from local storage
//     let userDetails = JSON.parse(localStorage.getItem('userDetails'));
    
//     // Safely access company ID
//     const userCompanyId = userDetails?.company?.company_id;

//     useEffect(() => {
//         const fetchBookings = async () => {
//             try {
//                 const response = await fetch("http://localhost:8080/api/bookings");
//                 const data = await response.json();

//                 if (userCompanyId) {
//                     // Filter bookings based on the user's company ID
//                     const userCompanyBookings = data.filter(
//                         booking => booking.userDetails.company.company_id === userCompanyId
//                     );

//                     setFilteredBookings(userCompanyBookings);
//                 } else {
//                     console.error("User company ID is not defined.");
//                 }
//             } catch (error) {
//                 console.error("Error fetching bookings:", error);
//             }
//         };

//         fetchBookings();
//     }, [userCompanyId]);

//     console.log('User Details:', userDetails);

//     const formatDate = (dateTime) => {
//         const date = new Date(dateTime);
//         return date.toLocaleDateString();
//     };

//     const formatTime = (dateTime) => {
//         const date = new Date(dateTime);
//         return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
//     };

//     return (
//         <div className="user-dashboard">
//             <h2>User Dashboard</h2>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>User Name</th>
//                         <th>Company</th>
//                         <th>Conference Room</th>
//                         <th>Date</th>
//                         <th>Start Time</th>
//                         <th>End Time</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {filteredBookings.map((booking) => (
//                         <tr key={booking.book_id}>
//                             <td>{booking.userDetails.userName}</td>
//                             <td>{booking.userDetails.company.company_name}</td>
//                             <td>{booking.confRoom.confName}</td>
//                             <td>{formatDate(booking.startTime)}</td>
//                             <td>{formatTime(booking.startTime)}</td>
//                             <td>{formatTime(booking.endTime)}</td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default UserDashBoard;


