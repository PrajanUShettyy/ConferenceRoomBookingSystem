import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Register = () => 
  {
  const [formData, setFormData] = useState(
    {
      userName: "",
      email: "",
      password: "",
      confirmPassword: "",
      companyName: "",
      roleName: "",
  });

  // const[roles,setRoles]=useState();
  const[companies,setCompanies]=useState([]);
  const [errors, setErrors] = useState({});
  const navigate=useNavigate();

  useEffect(()=>{
    const fetchCompanies=async()=>
    {
      try{
        const response=await fetch("http://localhost:8080/api/company");
        const data=await response.json();
        setCompanies(data);
      }
      catch(error)
      {
        console.log("Error fetching company",error);
      }
    };
    fetchCompanies();
  },[]);

  // useEffect(()=>{
  //   const fetchRoles = async()=>
  //   {
  //     try{
  //       const response=await fetch('http://localhost:8080/api/roles');
  //       const data= await response.json();
  //       setRoles(data);
  //     }
  //     catch(error)
  //     {
  //       console.log("Error fetchng roles",error);
  //     }
  //   };
  //   fetchRoles();
  // },[]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let valid = true;
    let errors = {};

    if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
      valid = false;
    }

    setErrors(errors);
    return valid;
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      // Fetch company_id and role_id if valid
      const companyResponse = await fetch(
        `http://localhost:8080/api/company/companyName/${formData.companyName}`
      );
      const company_id = await companyResponse.json();
      console.log(company_id)

      const roleResponse = await fetch(
        `http://localhost:8080/api/roles/role_name/${formData.roleName}` // Correct URL format
      );
      const roleId = await roleResponse.json();

      console.log(roleId);
      

      const payload = {
        userName: formData.userName,
        email: formData.email,
        password: formData.password,
        company:{
          company_id:company_id
        },
        role:{
          role_id:1
        }
      };

      console.log(payload);
    
      const response = await fetch("http://localhost:8080/api/userDetails/register", 
        {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) 
        {
        alert("Registration successful");
        navigate("/login");
        } 
        else if(response.status===500)
          {
            alert("You are already registered. Redirecting to the login page");
            navigate("/login");
          }
      else
      {
        alert("Registration failed");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while registering");
    }
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      <form onSubmit={handleRegister}>
        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            name="userName"
            value={formData.userName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Confirm Password</label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
          />
          {errors.confirmPassword && (
            <p className="error">{errors.confirmPassword}</p>
          )}
        </div>
        <div className="form-group">
          <label>Company Name</label>
          <select style={{width:"100%"}}
            name="companyName"
            value={formData.companyName}
            onChange={handleChange}
            required
            >
           <option value="">Select a company</option>
            {companies.map((company) => (
              <option key={company.company_id} value={company.companyId}>
                {company.company_name}
              </option>
            ))}
            </select>
     
        </div>
        <div className="form-group">
          <label>Role Name</label>
          <input
            type="text"
            name="roleName"
            value={formData.roleName}
            onChange={handleChange}
            required
          />

        </div>
        <button type="submit">Register</button>
      </form>
      <div className="link-to-login">
        <p>Already have an account? <a href="/login">Login here</a></p>
      </div>
    </div>
  );
};

export default Register;
