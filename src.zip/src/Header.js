 import { useEffect, useState } from "react";

 function Header()
{
    const [count ,setCount]=useState(0);
    const [seconds,setSeconds]=useState(0);

    useEffect(()=>
    {
        const interval=setInterval(()=> setSeconds(seconds+1),100);
        return()=> clearInterval(interval);
    },[seconds]);
   
    return(
        <>
        <p>{seconds} seconds Passed</p>

        <p>Please Click {count} times c</p>
        <button onClick={()=> setCount(count+1)}>Click ME</button>
               <h1>My website</h1>
        <nav>
            <ul>
                <li><a href="https://www.google.com">Home</a></li>
                <li><a href="yu">About</a></li>
                <li><a href="ce">Services</a></li>
                <li><a href="ce">Contact</a></li>

            </ul>
        </nav>
        </>

    )
}
export default Header

