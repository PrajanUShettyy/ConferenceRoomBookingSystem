import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './ConferenceRoomSelection.css';

const ConferenceRoomSelection = () => {
  const [rooms, setRooms] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/rooms');
        const data = await response.json();
        setRooms(data);
      } catch (error) {
        console.error('Error fetching rooms:', error);
      }
    };
    fetchRooms();
  }, []);

  const handleRoomClick = (conf_id) => {
    navigate(`/bookings/${conf_id}`);
  };

  return (
    <div className="room-selection-container">
      <h2>Select a Conference Room</h2>
      <div className="rooms">
        {rooms.map((room) => (
          <div key={room.conf_id} className="room" onClick={() => handleRoomClick(room.conf_id)}>
            {room.confName}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConferenceRoomSelection;
