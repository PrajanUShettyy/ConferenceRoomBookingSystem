import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminDashBoard.css";

const AdminDashBoard = () => {
  const [bookings, setBookings] = useState([]);
  const [companyName, setCompanyName] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/bookings");
        const data = await response.json();
        setBookings(data);
      } catch (error) {
        console.error("Error fetching bookings:", error);
      }
    };

    fetchBookings();
  }, []);

  const handleDelete = async (book_id) => {
    try {
      const response = await fetch(`http://localhost:8080/api/bookings/${book_id}`, {
        method: "DELETE",
      });
      if (response.ok) {
        setBookings(bookings.filter((booking) => booking.book_id !== book_id));
      } else {
        console.error("Failed to delete booking");
      }
    } catch (error) {
      console.error("Error deleting booking:", error);
    }
  };

  const handleAddCompany = async () => {
    if (!companyName.trim()) 
        {
            alert("Please enter a valid company name.");
            return;
        }   
    try {
      const response = await fetch("http://localhost:8080/api/company", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ company_name: companyName }),
      });
      if (response.ok) {
        alert("Company added successfully");
        setCompanyName("");
      } else {
        alert("Failed to add company");
      }
    } catch (error) {
      console.error("Error adding company:", error);
      alert("An error occurred while adding the company");
    }
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <div className="dashboard-actions">
        <div className="registerCSS">
        <button onClick={() => navigate("/register")}>Register User</button>
        </div>
        <div className="add-company">
          <input
            type="text"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
            placeholder="Enter Company Name"
          />
          <button onClick={handleAddCompany}>Add Company</button>
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>User Name</th>
            <th>Company</th>
            <th>Conference Room</th>
            <th>Date</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking) => (
            <tr key={booking.book_id}>
              <td>{booking.userDetails.userName}</td>
              <td>{booking.userDetails.company.company_name}</td>
              <td>{booking.confRoom.confName}</td>
              <td>{booking.startTime.split("T")[0]}</td>
              <td>{booking.startTime.split("T")[1]}</td>
              <td>{booking.endTime.split("T")[1]}</td>
              <td>
                <button
                  onClick={() => handleDelete(booking.book_id)}
                  className="delete-button"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminDashBoard;
