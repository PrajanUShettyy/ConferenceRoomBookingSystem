import React from "react";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import './App.css';
import BookingPage from './BookingPage';
// import ConferenceRoomSelection from "./ConferenceRoomSelection";
// import AdminDashboard from "./AdminDashboard";
import AdminDashBoard from "./AdminDashBoard";
import LandingPage from './LandingPage';
import Login from './Login';
import Register from './Register';
import UserDashBoard from "./UserDashBoard";

function App() {
    return (
      <Router>
        <div className="App">
          <Routes>
            <Route exact path="/" element={<LandingPage></LandingPage>} />
            <Route path="/login" element={<Login></Login>}></Route> 
            {/* <Route path="/rooms" element={<ConferenceRoomSelection />} /> */}
            <Route path="/register" element={<Register></Register>}/>
            <Route path="/bookings" element={<BookingPage />} />
            <Route path="/user-dashboard" element={<UserDashBoard/>}/>
            <Route path="/admin-dashboard" element={<AdminDashBoard/>}/>

            {/* <Route path="/booked-slots" element={<BookedSlots />} /> */}
          </Routes>
        </div>
      </Router>
    );
  }

export default App;
