import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import axios from '../axiosConfig';
import moment from 'moment-timezone';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Header from '../components/Header';

const BookingForm = () => {
    const { id: roomId } = useParams();
    const [startTime, setStartTime] = useState('');
    const [startTimes, setStartTimes] = useState([]);
    const [endTimes, setEndTimes] = useState([]);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [minDate, setMinDate] = useState(new Date());
    const [currentDateTime, setCurrentDateTime] = useState('');
    const [error, setError] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [bookingDetails, setBookingDetails] = useState(null);

    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const user_id = queryParams.get('      _id');

    useEffect(() => {
        const fetchCurrentDateTime = () => {
            const now = moment().tz('Asia/Kolkata');
            setCurrentDateTime(now.format('YYYY-MM-DDTHH:mm:ss'));
            setMinDate(new Date());
            setSelectedDate(new Date());
        };

        fetchCurrentDateTime();
        const timer = setInterval(fetchCurrentDateTime, 60000);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        if (selectedDate && currentDateTime) {
            const fetchStartTimes = async () => {
                try {
                    const formattedDate = selectedDate.toISOString().split('T')[0];
                    const response = await axios.get('/api/bookings/available-start-times', {
                        params: {
                            roomId,
                            date: formattedDate,
                            currentDateTime,
                        }
                    });
                    const availableTimes = Array.isArray(response.data) ? response.data : [];
                    
                    if (availableTimes.length === 0) {
                        alert('No available slots for this date.');
                    } else {
                        setStartTimes(availableTimes);
                    }
                } catch (error) {
                    setError('There are no available slots for this date.');
                    setStartTimes([]);
                }
            };

            fetchStartTimes();
        } else {
            setStartTimes([]);
            setEndTimes([]);
        }
    }, [selectedDate, currentDateTime, roomId]);

    useEffect(() => {
        const fetchEndTimes = async () => {
            if (startTime && selectedDate) {
                try {
                    const formattedDate = selectedDate.toISOString().split('T')[0];
                    const response = await axios.get('/api/bookings/available-end-times', {
                        params: {
                            roomId,
                            date: formattedDate,
                            startTime
                        }
                    });
                    setEndTimes(Array.isArray(response.data) ? response.data : []);
                } catch (error) {
                    setError('Failed to fetch available end times.');
                    setEndTimes([]);
                }
            }
        };

        fetchEndTimes();
    }, [startTime, selectedDate, roomId]);

    const handleStartTimeChange = (e) => {
        setStartTime(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const endTime = e.target['end-time'].value;
        const booking = {
            roomId,
            startTime: new Date(`${selectedDate.toISOString().split('T')[0]}T${startTime}:00`).toISOString(),
            endTime: new Date(`${selectedDate.toISOString().split('T')[0]}T${endTime}:00`).toISOString(),
        };
        const duration = moment(booking.endTime).diff(moment(booking.startTime), 'minutes');

        setBookingDetails({
            roomId,
            startTime: moment(booking.startTime).format('HH:mm'),
            endTime: moment(booking.endTime).format('HH:mm'),
            date: moment(selectedDate).format('YYYY-MM-DD'),
            duration
        });
        setShowModal(true);
    };

    const handleConfirmBooking = async () => {
        if (bookingDetails) {
            const formattedStartTime = moment(`${bookingDetails.date}T${bookingDetails.startTime}`, 'YYYY-MM-DDTHH:mm').format('YYYY-MM-DDTHH:mm:ss');
            const formattedEndTime = moment(`${bookingDetails.date}T${bookingDetails.endTime}`, 'YYYY-MM-DDTHH:mm').format('YYYY-MM-DDTHH:mm:ss');

            let bookingData = {
                room: {
                    id: bookingDetails.roomId
                },
                user: {
                    id: user_id
                },
                startTime: formattedStartTime,
                endTime: formattedEndTime,
                createdAt: null,
                updatedAt: null
            };

            try {
                console.log(bookingData);
                await axios.post('/api/bookings', bookingData);
                alert('Booking successful!');
            } catch (error) {
                alert('Booking failed.');
            }
            setShowModal(false);
        }
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <Header />
            <div className="mt-10 max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
                <h2 className="text-2xl font-bold mb-6 text-gray-700">Book a Conference Room</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {error && <p className="text-red-500">{error}</p>}

                    <div className="flex flex-col">
                        <label htmlFor="date" className="text-lg font-medium mb-1 text-gray-700">Booking Date:</label>
                        <DatePicker
                            id="date"
                            selected={selectedDate}
                            onChange={(date) => setSelectedDate(date)}
                            dateFormat="yyyy-MM-dd"
                            minDate={minDate}
                            className="p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>

                    <div className="flex flex-col">
                        <label htmlFor="start-time" className="text-lg font-medium mb-1 text-gray-700">Start Time:</label>
                        <select
                            id="start-time"
                            value={startTime}
                            onChange={handleStartTimeChange}
                            className="p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        >
                            <option value="" disabled>Select a start time</option>
                            {startTimes.map((time) => (
                                <option key={time} value={time}>{time}</option>
                            ))}
                        </select>
                    </div>

                    <div className="flex flex-col">
                        <label htmlFor="end-time" className="text-lg font-medium mb-1 text-gray-700">End Time:</label>
                        <select
                            id="end-time"
                            className="p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        >
                            <option value="" disabled>Select an end time</option>
                            {endTimes.map((time) => (
                                <option key={time} value={time}>{time}</option>
                            ))}
                        </select>
                    </div>

                    <button
                        type="submit"
                        className="w-full p-3 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        Book Now
                    </button>
                </form>

                {showModal && bookingDetails && (
                    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                        <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm mx-auto">
                            <h3 className="text-xl font-bold mb-4">Confirm Your Booking</h3>
                            <p className="mb-2"><strong>Date:</strong> {bookingDetails.date}</p>
                            <p className="mb-2"><strong>Start Time:</strong> {bookingDetails.startTime}</p>
                            <p className="mb-2"><strong>End Time:</strong> {bookingDetails.endTime}</p>
                            <p className="mb-4"><strong>Duration:</strong> {bookingDetails.duration} minutes</p>
                            <div className="flex justify-between">
                                <button
                                    onClick={handleConfirmBooking}
                                    className="p-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                                >
                                    Confirm
                                </button>
                                <button
                                    onClick={handleCloseModal}
                                    className="p-2 bg-red-500 text-white rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};

export default BookingForm;