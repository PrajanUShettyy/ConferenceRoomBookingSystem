import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import "./BookingPage.css";

const BookingPage = () => {
    const [date, setDate] = useState('');
    const [rooms, setRooms] = useState([]);
    const [selectedRoomId, setSelectedRoomId] = useState('');
    const [availableSlots, setAvailableSlots] = useState([]);
    const [selectedSlot, setSelectedSlot] = useState(null);    
    const navigate = useNavigate();
    const [bookedSlots, setBookedSlots] = useState([]);
    // const [loggedInUserId, setLoggedInUserId] = useState(1);

    useEffect(() => {
        axios.get('http://localhost:8080/api/rooms')
            .then(response => {
                setRooms(response.data);
            })
            .catch(error => {
                console.error('Error fetching rooms:', error);
            });
    }, []);

        // console.log(rooms);

    let userData = localStorage.getItem('userDetails');
    let userDetails = JSON.parse(userData);                                                                                                  //Parses the JSON string to convert it back to a JavaScript object.

    let user_id = userDetails.userId;

    useEffect(() => {
        if (date && selectedRoomId) {
            fetchBookedSlots(date, selectedRoomId);
            setAvailableSlots(generateTimeSlots());
        }
    }, [date, selectedRoomId]);

    const fetchBookedSlots = async (date, roomId) => {
        try {
            const response = await axios.get(`http://localhost:8080/api/bookings/room/${roomId}/date/${date}`);
            const bookings = response.data;

            // Extract booked start times from bookings
            const bookedTimes = bookings.map(booking => {
                const startTime = booking.startTime.split("T")[1].slice(0, 5); // Extract time (HH:mm)
                const endTime = booking.endTime.split("T")[1].slice(0, 5);
                return `${startTime} - ${endTime}`;
            });

            setBookedSlots(bookedTimes);
        } catch (error) {
            console.error("Error fetching booked slots:", error);
        }
    };

    // Generate time slots for 10 AM to 7 PM in 1-hour increments
    const generateTimeSlots = () => {
        const slots = [];
        let startHour = 10; 
        let endHour = 19; 

        for (let hour = startHour; hour < endHour; hour++) {
            slots.push(`${hour}:00 - ${hour}:30`);
            slots.push(`${hour}:30 - ${hour + 1}:00`);
        }
        return slots;
    };

    // Handle date and room selection
    const handleDateChange = (e) => 
    {
        setDate(e.target.value);
        //setAvailableSlots(generateTimeSlots()); // Generate slots whenever date changes
    };

    const handleRoomChange = (e) => 
    {
        setSelectedRoomId(e.target.value);
    };

    // const handleSlotClick = (slot) => {
    //     setSelectedSlot(slot);
    // };

    const handleBooking = async () => {
        if (!selectedSlot || !selectedRoomId || !date) {
            alert("Please select a date, room, and time slot.");
            return;
        }

        const [startTime, endTime] = selectedSlot.split(' - ');
        const bookingData = {
            userDetails: { userId: user_id },
            confRoom: { id: selectedRoomId },
            startTime: `${date}T${startTime}:00`,
            endTime: `${date}T${endTime}:00`,
        };

        try {
            const response = await fetch('http://localhost:8080/api/bookings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookingData),
            });

            if (response.ok) {
                alert("Booking successful!");
                fetchBookedSlots(date, selectedRoomId);
                navigate("/user-dashboard");
                  
            } else {
                alert("Booking failed");
            }
        } catch (error) {
            console.error("Error during booking:", error);
            alert("Booking failed");
        }
    };
    
    // const handleSubmit = (event) => {
    //     event.preventDefault();

    //     const bookingDetails = {
    //         date: date,
    //         roomId: selectedRoom,
    //         slot: selectedSlot
    //     };

    //     fetch('http://localhost:8080/api/bookings', {
    //         method: 'POST',
    //         headers: {
    //             'Content-Type': 'application/json',
    //         },
    //         body: JSON.stringify(bookingDetails)
    //     })
    //         .then(response => response.json())
    //         .then(data => {
    //             alert('Booking successful!');
    //         })
    //         .catch(error => {
    //             console.error('Error making booking:', error);
    //         });
    // };

    return (
        <div className="booking-container">
        <h2>Book a Conference Room</h2>

        <div className="form-group">
            <label>Select Date:</label>
            <input
                type="date"
                value={date}
                onChange={handleDateChange}
                className="form-control"
            />
        </div>

        <div className="form-group">
                <label>Select Conference Room:</label>
                <select
                    value={selectedRoomId}
                    onChange={handleRoomChange}
                    className="form-control"
                >
                    <option value="">Select a room</option>
                    {rooms.map(room => (
                        <option key={room.conf_id} value={room.id}>
                            {room.confName}
                        </option>
                    ))}
                </select>
            </div>

            <div className="form-group">
                <label>Select Time Slot:</label>
                <div className="slots-grid">
                    {availableSlots.map(slot => (
                        <button
                            key={slot}
                            className={`slot-button ${selectedSlot === slot ? 'selected' : ''}${bookedSlots.includes(slot) ? 'booked' : ''}`}
                            onClick={() => setSelectedSlot(slot)}
                            disabled={bookedSlots.includes(slot)}
                        >
                            {slot}
                        </button>
                    ))}
                </div>
            </div>

            <button onClick={handleBooking} className="btn btn-primary">
                Book Now
            </button>
        </div>
    );
};

export default BookingPage;
