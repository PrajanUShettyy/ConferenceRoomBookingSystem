package net.javaguides.springboot.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import net.javaguides.springboot.exception.BookingsException;
import net.javaguides.springboot.model.Bookings;
import net.javaguides.springboot.repository.BookingsRepository;
import net.javaguides.springboot.service.BookingsService;

@Service
public class BookingsServiceImpl implements BookingsService
{
	@Autowired
	private BookingsRepository bookingsRepository;

	public BookingsServiceImpl(BookingsRepository bookingsRepository) 
	{
		super();
		this.bookingsRepository = bookingsRepository;
	}
	
	@Override
	public Bookings saveBookings(@RequestBody Bookings bookings) 
	{
	    return bookingsRepository.save(bookings);
	}

	@Override
	public List<Bookings> getAllBookings() 
	{
		return bookingsRepository.findAll();
	}

	@Override
	public Bookings getBookingsById(int book_id) 
	{
		return bookingsRepository.findById(book_id).
				orElseThrow(()->new BookingsException("Bookings", book_id));
	}

	@Override
	public Bookings updateBookingsById(@RequestBody int book_id, Bookings bookings) 
	{
		if(!bookingsRepository.existsById(book_id))
		{
			throw new BookingsException("Bookings", book_id);
		}
		bookings.setBook_id(book_id);
		return bookingsRepository.save(bookings);
	}

	@Override
	public void deleteBookingsById(int book_id) 
	{
		Bookings bookings1=bookingsRepository.findById(book_id)
				.orElseThrow(()-> new BookingsException("Bookings", book_id));
		
		bookingsRepository.delete(bookings1);
	}

	@Override
	public List<Bookings> findBookingsByRoomAndDate(Integer roomId, LocalDate date) {
		LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);
		return bookingsRepository.findByConfRoom_IdAndStartTimeBetween(roomId, startOfDay, endOfDay);
	}
}
