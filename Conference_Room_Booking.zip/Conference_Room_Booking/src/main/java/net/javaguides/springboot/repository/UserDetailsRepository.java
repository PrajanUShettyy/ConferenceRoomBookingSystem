package net.javaguides.springboot.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.springboot.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, Integer>
{
	Optional<UserDetails> findByEmailAndPassword(String email, String password);
}















//@RestController
//@RequestMapping("/api/companies")
//public class CompanyController {
//
//    @Autowired
//    private CompanyRepository companyRepository;
//
//    @GetMapping("/id")
//    public ResponseEntity<Integer> getCompanyIdByName(@RequestParam String companyName) {
//        Company company = companyRepository.findByCompanyName(companyName)
//                .orElseThrow(() -> new ResourceNotFoundException("Company", "companyName", companyName));
//        return ResponseEntity.ok(company.getCompanyId());
//    }
//}
//
//@RestController
//@RequestMapping("/api/roles")
//public class RoleController {
//
//    @Autowired
//    private RoleRepository roleRepository;
//
//    @GetMapping("/id")
//    public ResponseEntity<Integer> getRoleIdByName(@RequestParam String roleName) {
//        Role role = roleRepository.findByRoleName(roleName)
//                .orElseThrow(() -> new ResourceNotFoundException("Role", "roleName", roleName));
//        return ResponseEntity.ok(role.getRoleId());
//    }
//}
