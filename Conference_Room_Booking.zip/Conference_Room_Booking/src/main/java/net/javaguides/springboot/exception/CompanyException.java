package net.javaguides.springboot.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)

public class CompanyException extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public CompanyException(String message)
	{
		super(message);
	}

//	public CompanyException(String string, String string2, String companyName)
//	{
//		
//	}
//	
//	public CompanyException(String entity,int company_id)
//	{
//		super(entity+ "not found at" +company_id);
//	}
}
