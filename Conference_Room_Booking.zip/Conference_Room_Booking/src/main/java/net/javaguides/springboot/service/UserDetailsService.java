package net.javaguides.springboot.service;

import java.util.List;
import java.util.Optional;

import net.javaguides.springboot.model.UserDetails;

public interface UserDetailsService 
{
	UserDetails saveUserDetails(UserDetails userDetails);
	List<UserDetails>getAllUserDetails();
	UserDetails getUserDetailsById(int userId);
	UserDetails updateUserDetailsById(int userId, UserDetails userDetails);
	void deleteUserDetailsById(int userId);
	
    Optional<UserDetails> login(String email, String password);

}
