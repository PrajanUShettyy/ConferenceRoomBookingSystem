package net.javaguides.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;

import net.javaguides.springboot.model.Bookings;

public interface BookingsRepository extends JpaRepository<Bookings, Integer>
{
	List<Bookings> findByConfRoom_IdAndStartTimeBetween(Integer roomId, LocalDateTime startOfDay,LocalDateTime endOfDay);
	
}