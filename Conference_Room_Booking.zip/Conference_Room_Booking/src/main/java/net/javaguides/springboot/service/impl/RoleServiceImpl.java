package net.javaguides.springboot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.javaguides.springboot.exception.RoleException;
import net.javaguides.springboot.model.Role;
import net.javaguides.springboot.repository.RoleRepository;
import net.javaguides.springboot.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService
{
	@Autowired
	private RoleRepository roleRepository;

	@Override
	public Role saveRole(Role role) 
	{
		return roleRepository.save(role);
	}

	@Override
	public List<Role> getAllRoles() 
	{
		return roleRepository.findAll();
	}

	@Override
	public Role getRoleById(int role_id) 
	{
		return roleRepository.findById(role_id).
				orElseThrow(()-> new RoleException("Role not found with "+role_id));
	}

	@Override
	public Role updateRoleById(int role_id, Role role) 
	{
		Role role1=roleRepository.findById(role_id).
				orElseThrow(()->new RoleException("Role not found with "+role_id));
	
		role1.setRole_name(role.getRole_name());
		return roleRepository.save(role1);
	}

	@Override
	public void deleteRoleById(int role_id) 
	{
		Role role1=roleRepository.findById(role_id).
				orElseThrow(()-> new RoleException("Role not found with "+role_id));
		
		roleRepository.delete(role1);
	}

	@Override
	public Integer findRoleIdByName(String role_name) 
	{
		return roleRepository.findRoleIdByName(role_name);
	}
}
