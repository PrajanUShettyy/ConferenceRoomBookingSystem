package net.javaguides.springboot.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.javaguides.springboot.exception.CompanyException;
import net.javaguides.springboot.model.Company;
import net.javaguides.springboot.repository.CompanyRepository;
import net.javaguides.springboot.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService
{
	@Autowired
	private CompanyRepository companyRepository;

	@Override
	public Company saveCompany(Company company) 
	{
		return companyRepository.save(company);
	}

	@Override
	public List<Company> getAllCompany() 
	{
		return companyRepository.findAll();
	}

	@Override
	public Company getCompanyById(int company_id) 
	{
		return companyRepository.findById(company_id).
				orElseThrow(()-> new CompanyException("Company not found with id"+ company_id));
	}

	@Override
	public Company updateCompanyById(int company_id, Company company) 
	{
		Company company1=companyRepository.findById(company_id).
				orElseThrow(()-> new CompanyException("Company not found with id"+ company_id));;
		
		company1.setCompany_name(company.getCompany_name());
		return companyRepository.save(company1);
	}

	@Override
	public void deleteById(int company_id) 
	{
		Company company1=companyRepository.findById(company_id)
				.orElseThrow(()-> new CompanyException("Company not found with id:" + company_id));
		
		companyRepository.delete(company1);
	}

	@Override
	public void deleteAllCompanies() 
	{
		companyRepository.deleteAll();
	}
	
	@Override
    public Integer findCompanyIdByName(String companyName)
	{
        return companyRepository.findCompanyIdByName(companyName);
	}
}
