package net.javaguides.springboot.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name="Bookings")
public class Bookings 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="book_id")
	private int book_id;
	
	@ManyToOne
	@JoinColumn(name="conf_id",nullable=false)
	private ConferenceRoom confRoom;
	
	@ManyToOne
	@JoinColumn(name="user_id",nullable=false)
	private UserDetails userDetails;
	
	@Column(name="StartTime")
	private LocalDateTime startTime;
	
	@Column(name="EndTime")
	private LocalDateTime endTime;

	
	public int getBook_id() {
		return book_id;
	}

	public ConferenceRoom getConfRoom() {
		return confRoom;
	}
	
	public UserDetails getUserDetails() {
		return userDetails;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	public void setConfRoom(ConferenceRoom confRoom) {
		this.confRoom = confRoom;
	}
	
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

}
