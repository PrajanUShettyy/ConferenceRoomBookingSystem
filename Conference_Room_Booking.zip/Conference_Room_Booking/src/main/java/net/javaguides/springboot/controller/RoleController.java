package net.javaguides.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.model.Role;
import net.javaguides.springboot.service.RoleService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/roles")

public class RoleController 
{
	@Autowired
	private RoleService roleService;
	
	@PostMapping
	public ResponseEntity<Role>saveRole(@RequestBody Role role)
	{
		return new ResponseEntity<Role>(roleService.saveRole(role), HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Role>> getAllRoles()
	{
		return ResponseEntity.ok(roleService.getAllRoles());
	}
	
	@GetMapping("{role_id}")
	private ResponseEntity<Role>getRoleById(@PathVariable("role_id") int role_id)
	{
		return ResponseEntity.ok(roleService.getRoleById(role_id));
	}
	
	@PutMapping("{role_id}")
	private ResponseEntity<Role>updateRoleById(@PathVariable("role_id") int role_id, @RequestBody Role role)
	{
		return ResponseEntity.ok(roleService.updateRoleById(role_id,role));
	}
	
	@DeleteMapping("{role_id}")
	public ResponseEntity<String> deleteRoleById(@PathVariable("role_id") int role_id) 
	{	
        roleService.deleteRoleById(role_id);
        return ResponseEntity.ok("Element deleted successfully at " + role_id);
	}
	
	@GetMapping("/role_name/{role_name}")
    public ResponseEntity<Integer> getRoleIdByName(@PathVariable("role_name") String role_name) {
        Integer role_id = roleService.findRoleIdByName(role_name);
        
        if (role_id != null) {
            return ResponseEntity.ok(role_id);  // Return role_id as JSON
        } else {
            return ResponseEntity.status(404).body(null);  // Return 404 if not found
        }
    }
}