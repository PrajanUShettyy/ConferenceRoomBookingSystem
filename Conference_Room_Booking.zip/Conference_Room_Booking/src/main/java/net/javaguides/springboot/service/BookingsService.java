package net.javaguides.springboot.service;

import java.time.LocalDate;
import java.util.List;

import net.javaguides.springboot.model.Bookings;

public interface BookingsService 
{
	Bookings saveBookings(Bookings bookings);
	List<Bookings> getAllBookings();
	Bookings getBookingsById(int book_id);
	Bookings updateBookingsById(int book_id, Bookings bookings);
	void deleteBookingsById(int book_id);

	List<Bookings> findBookingsByRoomAndDate(Integer roomId, LocalDate date);
}

