package net.javaguides.springboot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.javaguides.springboot.repository.ConferenceRoomRepository;
import net.javaguides.springboot.exception.ConferenceRoomException;
import net.javaguides.springboot.model.ConferenceRoom;
import net.javaguides.springboot.service.ConferenceRoomService;

@Service
public class ConferenceRoomServiceImpl implements ConferenceRoomService
{
	@Autowired
	private ConferenceRoomRepository conferenceRoomRepository;


	@Override
	public ConferenceRoom saveroom(ConferenceRoom ConfRoom) 
	{
		return conferenceRoomRepository.save(ConfRoom);
	}

	@Override
	public List<ConferenceRoom> getAllRooms() 
	{
		return conferenceRoomRepository.findAll();
	}

	@Override
	public ConferenceRoom getRoomById(int conf_id) 
	{
		return conferenceRoomRepository.findById(conf_id)
				.orElseThrow(()->new ConferenceRoomException("conference Room not found with id:" + conf_id));
	}

	@Override
	public ConferenceRoom updateRoomById(int conf_id, ConferenceRoom ConfRoom) 
	{
		ConferenceRoom ConfRoom1=conferenceRoomRepository.findById(conf_id)
				.orElseThrow(()->new ConferenceRoomException("conference Room not found with id:" + conf_id));
		
		ConfRoom1.setConfName((ConfRoom.getConfName()));
		return conferenceRoomRepository.save(ConfRoom1);
	}

	@Override
	public void deleteRoomById(int conf_id) 
	{
		ConferenceRoom ConfRoom2=conferenceRoomRepository.findById(conf_id)
				.orElseThrow(()-> new ConferenceRoomException("conference not found with exceprion:" +conf_id));
		
		conferenceRoomRepository.delete(ConfRoom2);
	}
}





//@Override
//public ConferenceRoom findByConfName(String confName) {
//      return conferenceRoomRepository.findByConfName(confName);
//  }

//@Override
//public int getConferenceRoomIdByName(String confName) {
//	ConferenceRoom conferenceRoom = conferenceRoomRepository.findByConfName(confName);
//  if (conferenceRoom != null) {
//      return conferenceRoom.getId();
//  } else {
//      throw new ConferenceRoomException("Conference Room not found with name: " + confName);
//  }
//}
