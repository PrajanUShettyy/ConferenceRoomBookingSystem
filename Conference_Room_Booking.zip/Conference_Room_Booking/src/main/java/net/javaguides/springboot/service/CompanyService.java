package net.javaguides.springboot.service;

import java.util.List;

import net.javaguides.springboot.model.Company;

public interface CompanyService
{
	Company saveCompany(Company company);
	List<Company> getAllCompany();
	Company getCompanyById(int company_id);
	Company updateCompanyById(int company_id, Company company);
	void deleteById(int company_id);
	void deleteAllCompanies();

	Integer findCompanyIdByName(String companyName);
}
