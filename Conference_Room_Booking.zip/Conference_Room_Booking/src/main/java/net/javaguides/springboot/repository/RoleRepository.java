package net.javaguides.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import net.javaguides.springboot.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer>
{
	@Query("SELECT r.role_id FROM Role r WHERE r.role_name = :role_name")
		    Integer findRoleIdByName(@Param("role_name") String role_name);
}
