package net.javaguides.springboot.service;

import java.util.List;

import net.javaguides.springboot.model.Role;

public interface RoleService 
{
	Role saveRole(Role role);
	List<Role>getAllRoles();
	Role getRoleById(int role_id);
	Role updateRoleById(int role_id,Role role);
	void deleteRoleById(int role_id);
	Integer findRoleIdByName(String role_name);
}
