package net.javaguides.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="conference_rooms")
public class ConferenceRoom 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "conf_id")
    private int conf_id;

    @Column(name = "conf_name")
    private String conf_name;

    public int getId() {
        return conf_id;
    }

    public void setId(int id) {
        this.conf_id = id;
    }

    public String getConfName() {
        return conf_name;
    }

    public void setConfName(String conf_name) {
        this.conf_name = conf_name;
    }
    
}
