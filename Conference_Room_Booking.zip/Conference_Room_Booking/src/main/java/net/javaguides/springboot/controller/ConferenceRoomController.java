package net.javaguides.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.model.ConferenceRoom;
import net.javaguides.springboot.service.ConferenceRoomService;

@RestController
@RequestMapping("/api/rooms")
public class ConferenceRoomController 
{
	@Autowired
	private ConferenceRoomService confRoomService;

	public ConferenceRoomController(ConferenceRoomService confRoomService)
	{
		super();
		this.confRoomService=confRoomService;
	}

//	@PostMapping("/name")
//	public ResponseEntity<ConferenceRoom> findIdByName(@RequestParam String name) {
//	    ConferenceRoom result = confRoomService.findByConfName(name);
//
//	    if (result == null) {
//	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//	    } else {
//	        return new ResponseEntity<>(result, HttpStatus.OK);
//	    }
//	}
	
//	@GetMapping("/conferenceRoomId")
//    public ResponseEntity<Integer> getConferenceRoomId(@RequestParam String confName) {
//        try {
//            int confId = confRoomService.getConferenceRoomIdByName(confName);
//            return ResponseEntity.ok(confId);
//        } catch (RuntimeException e) {
//            return ResponseEntity.notFound().build();
//        }
//    }

	@PostMapping
	public ResponseEntity<ConferenceRoom> saveroom (@RequestBody ConferenceRoom confRoom)
	{
		return new ResponseEntity<ConferenceRoom>(confRoomService.saveroom(confRoom),HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<ConferenceRoom>>getAllRooms()
	{
		return ResponseEntity.ok(confRoomService.getAllRooms());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<ConferenceRoom>getRoomById(@PathVariable("id") int conf_id)
	{
		return ResponseEntity.ok(confRoomService.getRoomById(conf_id));
	}
	  
	@PutMapping("/{id}")
	public ResponseEntity<ConferenceRoom>updateRoomById(@PathVariable("id") int conf_id, @RequestBody  ConferenceRoom confRoom)
	{
		return ResponseEntity.ok(confRoomService.updateRoomById(conf_id,confRoom));	
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String>deleteRoomById(@PathVariable ("id") int conf_id)
	{
		confRoomService.deleteRoomById(conf_id);
		return new ResponseEntity<String>("Employee deleted successfully",HttpStatus.OK);
	}
}
