package net.javaguides.springboot.controller;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import net.javaguides.springboot.service.BookingsService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.model.Bookings;


@RestController
@RequestMapping("/api/bookings")
public class BookingsController
{
	@Autowired
	private BookingsService bookingsService;
	
	@PostMapping
	public ResponseEntity<String>saveBookings(@RequestBody Bookings bookings)
	{
		bookingsService.saveBookings(bookings);
		return ResponseEntity.ok("Booking Successfull");
	}
	
	@GetMapping
	public ResponseEntity<List<Bookings>>getAllBookings()
	{
		return ResponseEntity.ok(bookingsService.getAllBookings());
	}
	
	@GetMapping("{book_id}")
	public ResponseEntity<Bookings>getAllBookingsById(@PathVariable int book_id)
	{
		return ResponseEntity.ok(bookingsService.getBookingsById(book_id));
	}
	
	@PutMapping("{book_id}")
	public ResponseEntity<Bookings>updateBookingsById(@PathVariable("book_id") @RequestBody int book_id, Bookings bookings)
	{
		return ResponseEntity.ok(bookingsService.updateBookingsById(book_id, bookings));
	}
	
	@DeleteMapping("{book_id}")
	public ResponseEntity<String>deleteBookingsById(@PathVariable int book_id)
	{
		bookingsService.deleteBookingsById(book_id);
		return ResponseEntity.ok("Element deleted at" +book_id);
	}
	
	@GetMapping("/room/{roomId}/date/{date}")
	public ResponseEntity<List<Bookings>> getBookingsByRoomAndDate(@PathVariable("roomId") Integer roomId, @PathVariable("date") String date)
	{
        LocalDate bookingDate = LocalDate.parse(date);
        List<Bookings> bookings = bookingsService.findBookingsByRoomAndDate(roomId, bookingDate);
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

}