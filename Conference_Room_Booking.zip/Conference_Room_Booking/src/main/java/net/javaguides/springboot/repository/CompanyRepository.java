package net.javaguides.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.javaguides.springboot.model.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> 
{
    @Query("SELECT c.company_id FROM Company c WHERE c.company_name = :companyName")
    Integer findCompanyIdByName(@Param("companyName") String companyName);

}
