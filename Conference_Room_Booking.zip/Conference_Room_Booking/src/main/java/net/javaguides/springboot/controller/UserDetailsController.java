package net.javaguides.springboot.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import net.javaguides.springboot.model.UserDetails;
import net.javaguides.springboot.service.UserDetailsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/userDetails")

public class UserDetailsController 
{
	@Autowired
	private UserDetailsService userDetailsService;
	
	public UserDetailsController(UserDetailsService userDetailsService) {
		super();
		this.userDetailsService = userDetailsService;
	}
	
	@PostMapping("/register")
	public ResponseEntity<String> saveUserDetails(@RequestBody UserDetails userDetails)
	{
		try {
		userDetailsService.saveUserDetails(userDetails);
        return ResponseEntity.ok("User registered successfully");
//		return new ResponseEntity<UserDetails>(userDetailsService.saveUserDetails(userDetails), HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error registering user: "+e.getMessage());
		}
	}

	
	@GetMapping
	public ResponseEntity<List<UserDetails>> getAllUserDetails()
	{
		return ResponseEntity.ok(userDetailsService.getAllUserDetails());
	}

	@GetMapping("{userId}")
	public ResponseEntity<UserDetails> getUserDetailsById(@PathVariable("userId") int userId)
	{
		return ResponseEntity.ok(userDetailsService.getUserDetailsById(userId));
	}
	
	@PutMapping("{userId}")
	public ResponseEntity<UserDetails> updateUserDetailsById(@PathVariable("userId") int userId, @RequestBody UserDetails userDetails)
	{
		return ResponseEntity.ok(userDetailsService.updateUserDetailsById(userId, userDetails)) ;
	}
	
	@DeleteMapping("{userId}")
	public ResponseEntity<String>deleteUserDetailsById(@PathVariable int userId)
	{
		userDetailsService.deleteUserDetailsById(userId);
        return ResponseEntity.ok("Element deleted successfully at " + userId);
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody Map<String, String> loginData) {
	    String email = loginData.get("email");
	    String password = loginData.get("password");

	    Optional<UserDetails> userOptional = userDetailsService.login(email, password);

	    if (userOptional.isPresent()) {
	        UserDetails user = userOptional.get();

	        // Create a response map to send specific user details back
	        Map<String, Object> response = new HashMap<>();
	        response.put("userId", user.getUserId());
	        response.put("userName", user.getUserName());
	        response.put("roleId", user.getRole().getRole_id());
	        response.put("email", user.getEmail());
	        // Add more fields if needed

	        return ResponseEntity.ok(response); // Send JSON response with user details
	    } else {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
	    }
	}

	
	
}