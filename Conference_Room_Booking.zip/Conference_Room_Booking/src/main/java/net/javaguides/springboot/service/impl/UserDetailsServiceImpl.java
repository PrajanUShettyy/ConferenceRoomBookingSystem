package net.javaguides.springboot.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.exception.UserDetailsException;
import net.javaguides.springboot.model.UserDetails;
import net.javaguides.springboot.repository.UserDetailsRepository;
import net.javaguides.springboot.service.UserDetailsService;

@Service
public class UserDetailsServiceImpl implements UserDetailsService
{
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	
	public UserDetailsServiceImpl(UserDetailsRepository userDetailsRepository) 
	{
		super();
		this.userDetailsRepository = userDetailsRepository;
	}

	@Override
	public UserDetails saveUserDetails(UserDetails userDetails) 
	{
		return userDetailsRepository.save(userDetails);
	}
	
	@Override
	public List<UserDetails> getAllUserDetails() 
	{
		return userDetailsRepository.findAll();
	}

	@Override
	public UserDetails getUserDetailsById(int userId) {
		return userDetailsRepository.findById(userId).
				orElseThrow(()-> new UserDetailsException("UserDetails" +userId));
	}

	@Override
	public UserDetails updateUserDetailsById(int userId, UserDetails userDetails) 
	{
		if(!userDetailsRepository.existsById(userId))
        {
            throw new UserDetailsException("User", userId);
        }
        userDetails.setUserId(userId);
        return userDetailsRepository.save(userDetails);  
	}

	@Override
	public void deleteUserDetailsById(int userId) 
	{
		 UserDetails userDetails1 = userDetailsRepository.findById(userId)
	                .orElseThrow(() -> new UserDetailsException("UserDetails", userId));

	        userDetailsRepository.delete(userDetails1);
	}

	@Override
	public Optional<UserDetails> login(String email, String password) {
		return userDetailsRepository.findByEmailAndPassword(email, password);
	}
}

