package net.javaguides.springboot.service;

import java.util.List;

import net.javaguides.springboot.model.ConferenceRoom;

public interface ConferenceRoomService 
{
	ConferenceRoom saveroom(ConferenceRoom confRoom);
	List<ConferenceRoom>getAllRooms();
	ConferenceRoom getRoomById(int conf_id);
	ConferenceRoom updateRoomById(int conf_id, ConferenceRoom ConfRoom);
	void deleteRoomById(int conf_id);
//	ConferenceRoom findByconfName(String confName);
//	int getConferenceRoomIdByName(String confName);
}